#!/bin/bash
#make by G.R.H

SH_DIR="$(cd $(dirname "$0"); pwd)"
THEME_NAME=$(basename "${0%.*}")   # This needs to be the same as the theme folder name
TARGET_DIR="/mnt/vendor"

if [ -d "${TARGET_DIR}/res1" ] && [ -d "${TARGET_DIR}/res2" ]; then
    cp -rf "${SH_DIR}/${THEME_NAME}"/* "${TARGET_DIR}"/
else
    cp -rf "${SH_DIR}/${THEME_NAME}"/res1/* "${TARGET_DIR}"/res/
fi
sync
exit 0